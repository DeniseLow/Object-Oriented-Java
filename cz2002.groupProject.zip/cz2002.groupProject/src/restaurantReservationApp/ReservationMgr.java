package restaurantReservationApp;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ReservationMgr {
	/**
	 * Store reservations in a 3D matrix
	 * Row: date
	 * Column: table ID
	 * Each table ID will have morning/afternoon slots
	 */
	private Reservation[][][] reservationMatrix;
	private int tableNum; // in this project, it is 30 tables.
	private int days; // in this project, it is set as one month (30 days)
	private TableMgr tableMgr;
	private Scanner sc = new Scanner(System.in);
	
	
	/**
	 * Initiate a ReservationMgr
	 * Load reservations from database
	 * @param tableMgr
	 */
	public ReservationMgr(TableMgr tableMgr){
		this.tableMgr = tableMgr;
		this.tableNum = 30;
		this.days = 30;
		reservationMatrix = new Reservation[days][tableNum][2];
		FileMgr.loadReservationMatrix(this);
	}
	
	/**
	 * Create an Reservation with given data, and add that reservation to the reservation matrix
	 * @param data
	 */
	public void addReservation(String[] data){
		Reservation res = new Reservation(data);
		int daysAfterToday = res.getArrDate().compareTo(LocalDate.now());
		int tableIndex = res.getTableId()-1;
		int AM = res.getArrTime().getHour()< 15? 0: 1;
		reservationMatrix[daysAfterToday][tableIndex][AM] = res;	
	}
	
	
	/**
	 * Find reservation with corresponding contact number to 1. print reservation details; 2. remove reservation; 3. check in of reservation guest
	 * @param hp
	 * @param choice 1. print reservation details; 2. remove reservation; 3. check in of reservation guest
	 * @return
	 */
	public int findReservation(int hp, int choice) {
		for (int i = 0; i< 30; i++){
			for (int j =0; j< 30; j++){
				for (int k = 0; k < 2; k++){
					if(reservationMatrix[i][j][k] != null && reservationMatrix[i][j][k].getHp() == hp){
						if (choice == 1){ //check reservation
							printReservation(reservationMatrix[i][j][k]);
							return 0;
						}
						else if (choice == 2){ //remove reservation
							reservationMatrix[i][j][k] = null;
							tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
							System.out.println("Reservation is removed");
							return 0;
						}
						else if(choice ==3){ // reservation guest arrive
							Reservation res = reservationMatrix[i][j][k];
							if (!res.getArrDate().equals(LocalDate.now()))
								return -1;
							int tableId = reservationMatrix[i][j][k].getTableId();
							reservationMatrix[i][j][k] = null; //delete reservation
							tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
							tableMgr.changeStatus(j, "occupied"); //change table status
							return tableId;
						}
					}
				}
			}
		}
		System.out.println("Error: reservation not found!");
		return -1;
	}

	
	/**
	 * Print the details of the Reservation
	 * @param res
	 */
	public void printReservation(Reservation res){
		System.out.println("==========================================================");
		System.out.println("                       RESERVATION                        ");
		System.out.println("==========================================================");
		System.out.println("Name: "+res.getCustName());
		System.out.println("Contact number: "+res.getHp());
		System.out.println("Pax: "+res.getPax());
		System.out.println("Table ID: "+res.getTableId());
		System.out.println("Arrival date: "+res.getArrDate());
		System.out.println("Arrival time: "+res.getArrTime());
		System.out.println("==========================================================");
	}

	
	/**
	 * Change table status to "reserved" on the date of reservation; change status to "vacant" if reservation time has passed 30 minutes.
	 * @param tables
	 * @param AM
	 */
	public void setTables(Table[] tables, boolean AM) {
		int index = 0;
		if (!AM)
			index= 1; //PM
		for (int i = 0; i < tableNum; i++){
			if (reservationMatrix[0][i][index] != null && tables[i].getStatus().compareToIgnoreCase("vacant") == 0){
				tables[i].changeStatus("reserved");
			}
			if (reservationMatrix[0][i][index] == null && tables[i].getStatus().compareToIgnoreCase("reserved") == 0){
				tables[i].changeStatus("vacant");
			}
		}
	}

	
	/**
	 * Delete the reservation if reservation time has passed 30 minutes.
	 */
	public void deleteExpiredRes(){ //will only check current day's reservation
		LocalTime currentTime = LocalTime.now();
		for (int i = 0; i < tableNum; i++) {
			int j = currentTime.getHour() < 15? 0:1;
			if (reservationMatrix[0][i][j] != null){
				LocalTime expiryTime = reservationMatrix[0][i][j].getArrTime().plusMinutes(30); // get expiryTime = arrTime + 30mins
				if (expiryTime.compareTo(currentTime) < 0){ //expiryTime past already
					reservationMatrix[0][i][j] = null; //delete expired reservations
					System.out.println("DEBUG : deleteExpiredRes");
				}
			}
		}
	}

	
	/**
	 * With given arrival date, time, and number of pax, find an available table, if table found, return the created reservation. Otherwise, return null.
	 * @param arrDate
	 * @param arrTime
	 * @param pax
	 * @return
	 */
	public Reservation addReservation(LocalDate arrDate, LocalTime arrTime, int pax) {
		LocalDate today = LocalDate.now();
		tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
		int daysAfterToday = arrDate.compareTo(today);
     	int index = arrTime.getHour() < 15 ? 0:1;
    	for (int i = 0; i < tableNum; i++){
        	if (pax <= tableMgr.getCapacity(i) && reservationMatrix[daysAfterToday][i][index] == null){
        		if (arrDate.equals(today) && arrTime.getHour() - LocalTime.now().getHour() < 2)
        			if (tableMgr.getStatus(i).compareToIgnoreCase("occupied") ==0)
        				continue;
        		Reservation res = new Reservation(arrDate, arrTime,pax,tableMgr.getTableID(i));
            	reservationMatrix[daysAfterToday][i][index] = res;
            	if (daysAfterToday == 0){
            		tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
            	}
             	return res;
            }
    	}
    	System.out.println("Sorry, no more available table for reservation.");
        return null;
	}

	
	/**
	 * update "reservationDB.txt"
	 */
	public void updateDB() {
		FileMgr.writeReservation(reservationMatrix);
	}
	
	
	/**
	 * Get user input to check reservation or remove reservation
	 */
	public void checkReservationUI(){
		try{
			System.out.println("1. Check reservation");
			System.out.println("2. Remove reservation");
			System.out.println("3. Back");
			
			System.out.println("Enter your choice: ");
			int c= sc.nextInt();
		
		
			switch (c){
				case 1 : case 2:
				{
					System.out.println("Contact Number?");
					int hp = sc.nextInt();
					int result = findReservation(hp, c);
					if (result == -1)
						System.out.println("Cannot find reservation.");
					break;
				}
				case 3:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;	
			}

		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			checkReservationUI();
		}
	
	}

	
	/**
	 * User interface
	 * User input arrival date, time and number of pax, system attempt to find available table to accommodate the reservation.
	 * If successful, reservation is created. Otherwise, unable to create reservation.
	 */
	public void bookReservationUI() {
		LocalDate arrDate = null;
		LocalTime arrTime = null;
		int flag = 0;
		do{
			
			try{
				System.out.println("Input arrival date (Format: yyyy-MM-dd, e.g. 2014-01-01): ");
				String dateStr = sc.next();
				arrDate = LocalDate.parse(dateStr);
				if (arrDate.isBefore(LocalDate.now()) || arrDate.isAfter(LocalDate.now().plusDays(30)))
					throw new Exception ("Error: unable to make reservation on that date."); 
				System.out.println("Input arrival time (Format: HH:MM, e.g. 18:00): ");
				String timeStr = sc.next();
				arrTime = LocalTime.parse(timeStr);
				if (arrTime.isBefore(LocalTime.parse("11:00")) || arrTime.isAfter(LocalTime.parse("22:00")) 
						|| (arrTime.isAfter(LocalTime.parse("15:00")) && arrTime.isBefore(LocalTime.parse("18:00"))))
					throw new Exception ("Error: unbale to make reservatio on that time.\n"
							+ "Operating hours: AM : 11am – 3pm, PM : 6pm – 10pm");
				if (arrDate.isEqual(LocalDate.now()) && arrTime.isBefore(LocalTime.now()))
					throw new Exception ("Error: reservation time has passed.");
				flag =1;
			}catch(DateTimeParseException e){
				System.out.println("Error: incorrect date/time format");
				continue;
			} catch (Exception e) {
				System.out.println(e.getMessage());
				continue;
			}
		}while (flag == 0);
		System.out.println("Input number of people: ");
		Reservation res = null;
		try{
			int pax= sc.nextInt();
			
			res = addReservation(arrDate, arrTime, pax);
			
			if (res == null){
				return;
			}
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			bookReservationUI();
		}
		flag = 0;
		do{
			
			try{
				sc.nextLine(); // flush
				System.out.print("Pleases enter the customer name:");
				String name = sc.nextLine();
				res.setName(name);
				System.out.print("Contact: ");
				int contact = sc.nextInt();
				res.setContact(contact);
				System.out.println("Reservation successful!");
				printReservation(res);
				flag =1;
			}catch(InputMismatchException e){
				System.out.println("Error: invalid input");
				sc.nextLine();
				continue;
			}
		}while (flag == 0);
		
	}
}
