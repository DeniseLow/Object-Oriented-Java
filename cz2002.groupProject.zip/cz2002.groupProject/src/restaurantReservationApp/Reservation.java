package restaurantReservationApp;

//import java.text.SimpleDateFormat;
import java.time.*;

public class Reservation {
	private String name;
	private int hp;
	private int pax;
	private int tableId;
	LocalDate arrDate;
	LocalTime arrTime;
	
	/**
	 * Create a reservation with data
	 * @param data
	 */
	public Reservation (String[] data){
		name = data[0];
		hp = Integer.parseInt(data[1]);
		pax = Integer.parseInt(data[2]);
		tableId = Integer.parseInt(data[3]);
		arrDate = LocalDate.parse(data[4]);
		arrTime = LocalTime.parse(data[5]);		
	}
		
	/**
	 * Create a reservation with given parameters
	 * @param arrDate
	 * @param arrTime
	 * @param pax
	 * @param tableID
	 */
	public Reservation(LocalDate arrDate, LocalTime arrTime, int pax, int tableID ) {
		this.arrDate = arrDate;
		this.arrTime = arrTime;
		this.pax = pax;
		this.tableId = tableID;
	}

	public int getTableId(){
		return tableId;
	}
	
	public LocalTime getArrTime(){
		return arrTime;
	}
	
	public LocalDate getArrDate(){
		return arrDate;
	}
		
	public String getCustName(){
		return name;
	}
	
	public int getHp(){
		return hp;
	}
	
	public int getPax(){
		return pax;
	}
	
	public void setArrTime(LocalTime time){
		arrTime = time;
	}
	
	public void setArrDate(LocalDate date){
		arrDate = date;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setContact(int num){
		hp = num;
	}
	
	public void setPax(int pax){
		this.pax = pax;
	}
	
}
