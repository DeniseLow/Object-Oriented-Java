package restaurantReservationApp;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;


public class RRPSS {
	private static FoodMgr foodMgr;
	private static PromoSetMgr promoSetMgr;
	private static OrderMgr orderMgr;
	private static TableMgr tableMgr;
	private static StaffMgr staffMgr;
	private static ReservationMgr reservationMgr;
	public static Scanner sc = new Scanner (System.in);
	
	
	public static void main(String[] args){
		foodMgr = new FoodMgr();
		promoSetMgr = new PromoSetMgr();
		tableMgr = new TableMgr();
		staffMgr = new StaffMgr();
		orderMgr = new OrderMgr();
		reservationMgr = tableMgr.reservationMgr;
		
		int choice =0;
		do 
		{
			System.out.println("**********************************************************");
			System.out.println("                     SCSE RESTAURANT                      ");
			System.out.println("**********************************************************");
			System.out.println("Enter your choice: ");
			System.out.println("1: Create/Update/Remove/Print menu item ");
			System.out.println("2: Create/Update/Remove/Print promotion");
			System.out.println("3: Create Order");
			System.out.println("4: View Order");
			System.out.println("5: Add/Remove order item/s to/from order");
			System.out.println("6: Create reservation booking");
			System.out.println("7: Check/Remove reservation booking");
			System.out.println("8: Check table availability");
			System.out.println("9: Print order invoice");
			System.out.println("10: Print sale revenue report by period");
			System.out.println("11: Quit");
			System.out.println("**********************************************************");
			try{
				choice = sc.nextInt();	
				switch(choice)
				{
					case 1: //add/update/remove menu item
						foodMgr.foodUI();
						break;
					case 2://add/update/remove promoset
						promoSetMgr.promoSetUI();
						break;
					case 3://create an order
						createOrderUI();
						break;
					case 4://view order
						orderMgr.viewOrderUI();
						break;
					case 5://add/remove order item/s to/from order
						orderMgr.modifyOrderUI();
						break;
					case 6://reservation booking
						reservationMgr.bookReservationUI();
						break;
					case 7:// check/remove reservation booking
						reservationMgr.checkReservationUI();
						break;
					case 8 :
						tableMgr.printTableStatus();
						break;
					case 9:
						checkOutUI();
						break;
					case 10:
						orderMgr.printSaleRev();
						break;
					case 11 ://quit
						exitUI();
						break;
					default:
						System.out.println("Error: invalid input!");
						break;
				}
			}catch (ItemNotFoundException e){
				System.out.println("Error: " + e.getMessage() + " not found! Please check " + e.getMessage());
			}catch (InputMismatchException e1){
				System.out.println("Error: RRPSS invalid input data type!");
				System.out.println("Please enter again");
				sc.next();
			}catch (Exception e2){
				System.out.println(e2.getMessage());
			}
		}while (choice != 11);
	}

	/**
	 * Update database
	 */
	private static void exitUI() {
		foodMgr.updateDB();
		promoSetMgr.updateDB();
		reservationMgr.updateDB();
		tableMgr.updateDB();
		orderMgr.updateDB();
		System.out.println("End of program execution!");
	}

	/**
	 * User interface to create order. If the user has reservation, take him to the assigned table and take the order.
	 * If the user does not have reservation, find an available table and take the order. If not found, unable to take the order.
	 * @throws ItemNotFoundException
	 */
	private static void createOrderUI() throws ItemNotFoundException {
		
		int tableId, staffId;
		try{
			System.out.print("Do you have a reservation? y/n ");
			int result = sc.next().charAt(0);
			if (result == 'n'){  //without reservation
				System.out.print("Pax:");
		        int pax = sc.nextInt();
	
				tableId = tableMgr.assignTable(pax);
				if (tableId == -1){
					System.out.println("Error: no available table!");
					return;
				}
			}
			else if (result == 'y'){ //with reservation
				System.out.println("Contact number: ");
				int contact = sc.nextInt();
				tableId = reservationMgr.findReservation(contact, 3); //reservation guest arrive, get tableId;
				if (tableId == -1){
					return;
				}
			}
			else{
				System.out.println("Error: invalid input!");
				return;
			}
			
			System.out.print("Enter staff ID: ");
			staffId = sc.nextInt();
			if (staffMgr.getStaffByID(staffId) == null)
				throw new ItemNotFoundException("staff");
			Order order = orderMgr.addOrder(tableId, staffId);
			System.out.println("You are assigned to table " + order.getTableID());
			System.out.println("Your order ID is : " + order.getOrderID());
			System.out.println();
			orderMgr.addItemUI(order);
			System.out.println("Order is successfully placed!");
			orderMgr.printOrder(order);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			createOrderUI();
		}
	}
	
	
	/**
	 * User interface
	 * User input ordr ID. print the receipt of the order and change table status to "vacant".
	 * @throws ItemNotFoundException
	 */
	private static void checkOutUI() throws ItemNotFoundException {
		try{
			System.out.println("Enter order ID");
			int orderID = sc.nextInt();
			Order order = orderMgr.getOrderById(orderID);
			if (order == null)
				throw new ItemNotFoundException("order");
			orderMgr.printReceipt(order);
			int tableID = order.getTableID();
			tableMgr.changeStatus(tableID-1, "vacant");
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			checkOutUI();
		}
	}

	

	
}
