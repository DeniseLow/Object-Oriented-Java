package restaurantReservationApp;

public class Table {
	private int tableID;
	private int capacity;
	private String status;
	
	public Table(int id, int capacity, String status){
		tableID = id;
		this.capacity = capacity;
		this.status = status;
	}
	
	public int getTableID(){
		return tableID;
	}

	public int getCapacity(){
		return capacity;
	}
	
	public String getStatus(){
		return status;
	}
	
	public void setTableID(int id){
		tableID = id;
	}
	
	public void setCapacity(int capacity){
		this.capacity = capacity;
	}
	
	public void changeStatus(String status){
		this.status = status;
	}
	
}
