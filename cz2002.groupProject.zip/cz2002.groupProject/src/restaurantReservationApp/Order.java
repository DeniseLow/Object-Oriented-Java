package restaurantReservationApp;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

public class Order {
	
	/**
	 * Contains Food/PromoSet and respective quantity
	 */
	private Map<MenuItem, Integer> foodList = new HashMap<MenuItem, Integer>();
	
	private double price;
	
	/**
	 * Total price after GST and service charge
	 */
	private double totalPrice;
	
	private double gst;
	
	private double scharge;
	
	/**
	 * Unique order ID
	 */
	private int orderID;
	
	/**
	 * Table ID associated with the order
	 */
	private int tableID;
	
	/**
	 * ID of the staff who takes the order
	 */
	private int staffId;
	
	/**
	 * Date when the order is created
	 */
	private LocalDate date;
	
	/**
	 * Time when the order is created
	 */
	private LocalTime time;
	
	/**
	 * Create an Order with given attributes. (Read from database)
	 * @param attributes
	 */
	public Order(String[] attributes){
		this.orderID = Integer.parseInt(attributes[0]);
		this.staffId = Integer.parseInt(attributes[1]);
		this.tableID = Integer.parseInt(attributes[2]);
		this.date = LocalDate.parse(attributes[3]);
		this.time = LocalTime.parse(attributes[4]);
	}
	/**
	 * Create an order with orderId, tableId, and staffId. Date and time are initiated to time of creation.
	 * Food list is empty, and can be added later
	 * @param orderId
	 * @param tableId
	 * @param staffId
	 */
	public Order(int orderId, int tableId, int staffId){
		foodList = new HashMap<MenuItem, Integer>();
		this.orderID = orderId;
		this.staffId = staffId;
		this.tableID = tableId;
		date = LocalDate.now();
		time = LocalTime.now();
	}
	
	/**
	 * Add respective amount of Food/PromoSet to the order
	 * @param item Food/PromoSet
	 * @param quantity
	 */
	public void addToOrder(MenuItem item, int quantity){
		double priceDiff = item.getPrice() * quantity;
		if (foodList.containsKey(item))
			quantity += (int)foodList.get(item);
		foodList.put(item, quantity);
		price += priceDiff;
		double itemGST = priceDiff * 0.07;
		gst += itemGST;
		double itemSCharge = (priceDiff + itemGST)*0.1;
		scharge += itemSCharge;
		totalPrice += (priceDiff + itemGST + itemSCharge);
	}

	/**
	 * Remove respective amount of Food/PromoSet from the order, return 0 if successful, -1 if unsuccessful.
	 * @param item
	 * @param quantity
	 * @return 0 or -1 depending on whether successfully removed.
	 */
	public int removeFromOrder (MenuItem item, int quantity){
		double priceDiff = item.getPrice() * quantity;
		if (foodList.containsKey(item)){
			int q = (int)foodList.get(item) - quantity;
			if (q > 0){
				foodList.put(item, q);
				price -= priceDiff;
				gst -= priceDiff *0.07;
				scharge -= (priceDiff*1.07)*0.1;
				totalPrice -= price + gst + scharge;
				return 0;
			}
		}
		return -1;
	}
	
	/**
	 * Returns the foodList of the Order
	 * @return foodList
	 */
	public Map<MenuItem, Integer> getFoodList() {
		return foodList;
	}
	
	
	public int getOrderID(){
		return orderID;
	}
	
	public void setOrderID(int orderID){
		this.orderID = orderID;
	}
	
	public double getPrice(){
		return price;
	}
	
	public void setPrice(double price){
		this.price = price;
	}
	
	public double getGST(){
		return gst;
	}
	
	public void setGST(double gst){
		this.gst = gst;
	}
	
	public double getScharge(){
		return scharge;
	}
	
	public void setScharge(double scharge){
		this.scharge = scharge;
	}
	
	public double getTotalPrice(){
		return totalPrice;
	}
	
	public void setTotalPrice(double totalPrice){
		this.totalPrice = totalPrice;
	}
	
	public int getStaffId(){
		return staffId;
	}
	
	public LocalDate getDate(){
		return date;
	}
	
	public void setStaff(int staffId){
		this.staffId = staffId;
	}
	
	public int getTableID(){
		return tableID;
	}
	
	public void setTableID(int tableID){
		this.tableID = tableID;
	}
	
	
	/**
	 * Get date and time of the order.
	 * @return
	 */
	public String getDateTime() {
		String dateTime = date.toString() + "," +time.toString();
		return dateTime;
	}
	
	/**
	 * Get number of different Food/PromoSet in the order
	 * @return
	 */
	public int getOrderSize(){
		return foodList.size();
	}
	
}
