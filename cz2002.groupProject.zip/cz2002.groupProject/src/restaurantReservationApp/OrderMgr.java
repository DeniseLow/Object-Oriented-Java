package restaurantReservationApp;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class OrderMgr {
	private Scanner sc = new Scanner(System.in);
	
	/**
	 * Contains all the orders
	 */
	private ArrayList<Order> orderList = new ArrayList<Order>();
	
	/**
	 * Load order history from database
	 */
	public OrderMgr(){
		FileMgr.loadOrder(this);
	}
	
	/**
	 * Add the Order to orderList
	 * @param order
	 */
	public void addOrder (Order order){
		orderList.add(order);
	}
	
	/**
	 * Create a new Order and add the Order to the orderList. New Order does not have any Food/PromoSet.
	 * @param tableId
	 * @param staffId
	 * @return new Order created
	 */
	public Order addOrder(int tableId, int staffId) {
		int orderID = orderList.size()+1;
		Order order = new Order(orderID, tableId, staffId);
		orderList.add(order);
		return order;
	}
	
	/**
	 * Get the Order with corresponding ID, if not found, return null.
	 * @param orderID
	 * @return the Order
	 */
	public Order getOrderById(int orderID){
		for (Order order: orderList)
			if (order.getOrderID() == orderID)
				return order;
		return null;
	}
	
	/**
	 * Add respective amount of Food/PromoSet to the Order
	 * @param order
	 * @param item
	 * @param quantity
	 */
	public void addToOrder(Order order, MenuItem item, int quantity){
		order.addToOrder(item, quantity);
		System.out.println("Food successfully added to order!");
	}
	
	
	/**
	 * Remove respective amount of Food/PromoSet from the Order. Return 0 if successful, otherwise return -1.
	 * @param order
	 * @param item
	 * @param quantity
	 * @return
	 */
	public int removeFromOrder(Order order, MenuItem item, int quantity){
		int result =  order.removeFromOrder(item, quantity);
		if (result ==0){
			System.out.println("Error: unable to remove food. Check order!");
			return -1;
		}
		System.out.println("Food successfully removed from order!");
		return 0;
	}
	
	
	/**
	 * Print the Food/PromoSet and quantity in the Order
	 * @param order
	 */
	public void printOrder(Order order){
		Map<MenuItem, Integer> foodOrderList = order.getFoodList();
		Set<MenuItem> itemSet = foodOrderList.keySet();
		System.out.println("============================================================================");
		System.out.println("Order ID: " + order.getOrderID());
		System.out.printf("%-5s %-50s %-10s\n", "ID", "Name", "Quantity");
		
		for(MenuItem item: itemSet)
			System.out.printf("%-5d %-50s %-10d\n",item.getID(),item.getName(), foodOrderList.get(item));
		System.out.println("============================================================================");
	}
	
	
	/**
	 * Print the receipt of the order
	 * @param order
	 */
	public void printReceipt(Order order){
		Map<MenuItem, Integer> foodOrderList = order.getFoodList();
		Set<MenuItem> itemSet = foodOrderList.keySet();
		System.out.println("============================================================================");
		System.out.println("                               SCSE RESTAURANT                              ");
		System.out.println("                               Nanyang Avenue                               ");
		System.out.println("                                  65432107                                  ");
		System.out.println("Staff : " + order.getStaffId());
		System.out.println("Table number : "+ order.getTableID());
		System.out.println(order.getDateTime().toString());
		System.out.println("============================================================================");
		
		for(MenuItem item: itemSet)
			System.out.printf("%-5d %-50s %-10.2f\n",foodOrderList.get(item),item.getName(), item.getPrice());
		System.out.println("============================================================================");
		System.out.printf("%52s %10.2f\n","Total: ", order.getPrice());
		System.out.println();
		System.out.println("                         Thanks for dining with us!                         ");
		System.out.println();
		System.out.println("============================================================================");
	}
	

	/**
	 * Get user input to add Food/PromoSet.
	 * @param order
	 */
	public void addItemUI(Order order){
		try{
			int c;
			do{
				System.out.println("1: Add food");
				System.out.println("2: Add promotional set" );
				System.out.println("3. Quit");
				c = sc.nextInt();
				switch (c){
					case 1:
						addFoodUI(order);
						break;
					case 2:
						addPromoSetUI(order);
						break;
					case 3:
						break;
					default:
						System.out.println("Error: invalid input!");
						break;
					
				}
			} while (c != 3);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			addItemUI(order);
		}catch(ItemNotFoundException e1){
			System.out.println("Error: " + e1.getMessage() + " not found! Please check " + e1.getMessage());
			sc.nextLine();
			addItemUI(order);
		}
		
		
	}

	/**
	 * User interface
	 * User input promoSet ID, and quantity, add the PromoSet to the order
	 * @param order
	 * @throws ItemNotFoundException
	 */
	private void addPromoSetUI(Order order) throws ItemNotFoundException {
		try{
			System.out.println("Enter promotional set id and the quantity");
			int id = sc.nextInt();
			PromoSet promoSet = PromoSetMgr.getPromoSetByID(id);
			if (promoSet == null){
				throw new ItemNotFoundException("promotional set");
			}
			int quantity=sc.nextInt();
			addToOrder(order,promoSet, quantity);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			addPromoSetUI(order);
		}
	}

	/**
	 * User interface
	 * User input foodId and quantity, add the Food to the Order
	 * @param order
	 * @throws ItemNotFoundException
	 */
	private void addFoodUI(Order order) throws ItemNotFoundException {
		try{
			System.out.println("Enter food id and the quantity");
			int id=sc.nextInt();
			Food food = FoodMgr.getFoodByID(id);
			if (food == null){
				throw new ItemNotFoundException("food");
			}
			int quantity=sc.nextInt();
			addToOrder(order,food, quantity);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			addFoodUI(order);
		}
	}
	
	/**
	 * Get user input of order ID, print Food/PromoSet and quantity contained in the Order
	 * @throws ItemNotFoundException
	 */
	public void viewOrderUI() throws ItemNotFoundException {
		try{
			System.out.print("Enter the order id:");
			int orderId;
			
			orderId=sc.nextInt();
		
			Order order= getOrderById(orderId);
			if(order ==null){
				throw new ItemNotFoundException("order");
			}
			printOrder(order);
			
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			viewOrderUI();
		}
	}

	/**
	 * User interface
	 * User input promotional set id and quantity to be removed. Remove the PromoSet
	 * @param order
	 * @throws ItemNotFoundException
	 */
	private void removePromoSetUI(Order order) throws ItemNotFoundException {
		try{
			System.out.println("1: Enter the promotional set id and the amount");
			int id=sc.nextInt();
			PromoSet promoSet = PromoSetMgr.getPromoSetByID(id);
			if (promoSet== null){
				throw new ItemNotFoundException("promotional set");
			}
			int quantity=sc.nextInt();
			order.removeFromOrder(promoSet, quantity);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			removePromoSetUI(order);
		}
	}

	/**
	 * User interface
	 * User input the Food and quantity to be remove. Remove the Food
	 * @param order
	 * @throws ItemNotFoundException
	 */
	private void removeFoodUI(Order order) throws ItemNotFoundException {
		try{
			System.out.println("1: Enter the food id and the amount");
			int id=sc.nextInt();
			Food food = FoodMgr.getFoodByID(id);
			if(food == null){
				throw new ItemNotFoundException("food");
			}
			int quantity=sc.nextInt();
			int result = order.removeFromOrder(food, quantity);
			if(result == 0)
				System.out.println("Food successfully removed!");
			else
				System.out.println("Error: not able to remove food. Check order!");
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			removeFoodUI(order);
		}
	}
	
	/**
	 * User interface
	 * Remove Food/PromoSet from the order
	 * @param order
	 * @throws ItemNotFoundException
	 */
	private void removeItemUI(Order order) throws ItemNotFoundException {
		try{
			int c;
			do{
				System.out.println("1: Remove food");
				System.out.println("2: Remove promotional set" );
				System.out.println("3. Quit");
				c = sc.nextInt();
				switch (c){
					case 1:
						removeFoodUI(order);
						break;
					case 2:
						removePromoSetUI(order);
						break;
					case 3:
						break;
					default:
						System.out.println("Error: invalid input!");
						break;
					
				}
			} while (c != 3);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			removeItemUI(order);
		}
	}
	
	/**
	 * Get user input to add/remove food to/from order
	 * @throws ItemNotFoundException
	 */
	public void modifyOrderUI() throws ItemNotFoundException {
		try{
			System.out.print("Enter the order id:");
			int orderId;
			orderId=sc.nextInt();
			Order order= getOrderById(orderId);
			if(order ==null){
				throw new ItemNotFoundException("order");
			}
			System.out.println("1: Add order items to order");
			System.out.println("2: Remove order items from order");
			System.out.println("3: Quit");
			int c=sc.nextInt();
			switch(c) 
			{
				case 1:	//add stuff to the order
				{
					addItemUI(order);
					break;
				}
				case 2: // remove from order
				{
					removeItemUI(order);
					break;
				}
				default: 
				{
					System.out.println("Error: invalid input!");
					break;
				}
			}
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			modifyOrderUI();
		}
	}

	/**
	 * Update "order.txt"
	 */
	public void updateDB() {
		FileMgr.writeOrder(orderList);
	}

	public void printSaleRev() {
		Revenue revenue = new Revenue(orderList);
		revenue.printSaleRevUI();
	}
}
