<?php

	//get elements of the form
	$username = $_POST["username"];
	$appleQty = (int)$_POST["appleQty"];
	$orangeQty = (int)$_POST["orangeQty"];
	$bananaQty = (int)$_POST["bananaQty"];
	$paymentMethod = $_POST["paymentMethod"];

	//calculate costs of each fruit ordered
	$appleCost = 0.69 * $appleQty;
	$orangeCost = 0.59 * $orangeQty;
	$bananaCost = 0.39 * $bananaQty;
	
	//calculate total cost of fruits ordered
	$totalCost = ($appleCost + $orangeCost + $bananaCost);

	//determine whether file exists before trying to open it
	if (file_exists("order.txt")) {
	  $order_file = file("order.txt");
	  
	  //getting the quantities of fruits previously ordered
	  sscanf($order_file[0], "Total number of apples: %d", $initialApple);
	  sscanf($order_file[1], "Total number of oranges: %d", $initialOrange);
	  sscanf($order_file[2], "Total number of bananas: %d", $initialBanana);
	}

	//calculate updated total quantity with new order
	$finalApple = $initialApple + $appleQty;
	$finalOrange = $initialOrange + $orangeQty;
	$finalBanana = $initialBanana + $bananaQty;


	//acquire exclusive lock to write into file
	$fp = fopen("./order.txt", "w");
	if (!flock($fp, LOCK_EX | LOCK_NB)) {
	  echo "Unable to obtain lock";
	  exit(-1);
	}

	//write into file the updated quantities of fruits ordered
	fprintf($fp, "Total number of apples: %d\r\n", $finalApple);
	fprintf($fp, "Total number of oranges: %d\r\n", $finalOrange);
	fprintf($fp, "Total number of bananas: %d\r\n", $finalBanana);
	
	//close file after writing into it
	fclose($fp);
?>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <title> Fruit Order Receipt </title>
</head>

<style type="text/css">
body{
background-color: 	#000000; 
color:white;
text-align:center;
}
table, td,th {
    border: 1px solid white;
}
th, td {
    padding: 5px;
}
</style>

<body>
<div align="center" style="background-color: #4C9900;color:white;padding:20px;" >
<h2> Fruit Order Receipt </h2>

<!-- Table to show required fields -->
<table align = "center" border = "1">
	
	<!-- First row: showing name of customer -->
	<tr>
		<td colspan = 4 ; align = 'left'>
		Hello <?php echo $_POST["username"]; ?>
		<br />
		The following is your order:
		</td>
	</tr>
	
	<!-- Second row: Column Header -->
	<tr>
	<th>Item: </th>
	<th>Cost:</th>
	<th>Quantity: </th>
	<th>Cost:</th>
	</tr>
	
	<!-- Third row: for Apple -->
	<tr>
		<td> Apple</td>
		<td> $0.69 </td>
		<!-- show quantity of apples bought -->
		<td><?php echo $_POST['appleQty']; ?> </td>
		<!-- show total cost of apples bought -->
		<td>$<?php echo $appleCost;?></td>
	</tr>
	
	<!-- Fourth row: for Orange -->
	<tr>
		<td> Orange</td>
		<td> $0.59 </td>
		<!-- show quantity of oranges bought -->
		<td> <?php echo $_POST['orangeQty']; ?> </td>
		<!-- show total cost of oranges bought -->
		<td>$<?php echo $orangeCost;?></td>
	</tr>
	
	<!-- Fifth row: for Banana -->
	<tr>
		<td> Banana</td>
		<td> $0.39 </td>
		<!-- show quantity of banana bought -->
		<td><?php echo $_POST['bananaQty']; ?> </td>
		<!-- show total cost of banana bought -->
		<td>$<?php echo $bananaCost;?></td>
	</tr>
	
	<!-- Sixth row: for total cost -->
	<tr>
		<td colspan = 4 >
		Total cost is : <?php printf ("$ %5.2f <br />", $totalCost); ?>
		</td>
	</tr>
	
	<!-- Seventh row: for payment method -->
	<tr>
		<td colspan = 4>
		Payment method is : <?php echo $_POST["paymentMethod"]; ?>
		</td>
	</tr>
	
</table>
</div>
</body>

</html>