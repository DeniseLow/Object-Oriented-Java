package finalcompilation.finalfivemin;

/**
 * Created by Ernest on 19/3/2017.
 */

public class Constants {

    public static final String USER_ID_INTENT = "userID";

    public static final int ARTICLE_SOURCE_SHAPE = 0;
    public static final int ARTICLE_SOURCE_ASIAONE = 1;

    public static final String ARTICLE_LINK_SHAPE ="http://www.shape.com.sg/taxonomy/term/3/feed";
    public static final String ARTICLE_LINK_ASIAONE = "http://www.asiaone.com/rss-feed/41581";
}
